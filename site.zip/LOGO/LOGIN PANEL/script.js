const loginBox = document.querySelector(".login-box");
const signupBox = document.querySelector(".signup-box");

const showSignup = document.getElementById("showSignup");
const showLogin = document.getElementById("showLogin");

const loginForm = document.getElementById("loginForm");
const signupForm = document.getElementById("signupForm");
const verificationForm = document.getElementById("verificationForm");
const passwordRecoveryForm = document.getElementById("passwordRecoveryForm");
const passwordResetForm = document.getElementById("passwordResetForm");

const message = document.getElementById("message");
const adminPortal = new URLSearchParams(window.location.search).get("portal") === "admin";
const usernameFields = [document.getElementById("signupUsername")];
const disallowedUsernameCharacters = /[^A-Za-z0-9_@*]/g;
const fullNameField = document.getElementById("signupFullName");
const birthDateField = document.getElementById("signupBirthDate");
const localToday = () => {
    const now = new Date();
    return `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, "0")}-${String(now.getDate()).padStart(2, "0")}`;
};
birthDateField.max = localToday();
const passwordFields = [
    document.getElementById("signupPassword"),
    document.getElementById("confirmPassword"),
    document.getElementById("newPassword"),
    document.getElementById("confirmNewPassword")
].filter(Boolean);
const profilePhotoStorageKey = "nexora-profile-photo";
let pendingVerificationEmail = "";
let pendingRecoveryEmail = "";
let signupConsent = null;

function restrictInputCharacters(field, disallowedCharacters) {
    field.addEventListener("input", () => {
        const cursor = field.selectionStart;
        const cleanPrefix = field.value.slice(0, cursor).replace(disallowedCharacters, "");
        field.value = field.value.replace(disallowedCharacters, "");
        field.setSelectionRange(cleanPrefix.length, cleanPrefix.length);
    });
}

usernameFields.forEach((field) => {
    restrictInputCharacters(field, disallowedUsernameCharacters);
});
restrictInputCharacters(fullNameField, /[^A-Za-z ]/g);
passwordFields.forEach((field) => restrictInputCharacters(field, /[^A-Za-z0-9#*_]/g));
window.addEventListener("pointermove", (event) => {
    const x = (event.clientX / window.innerWidth) * 100;
    const y = (event.clientY / window.innerHeight) * 100;

    document.body.style.setProperty("--mx", x.toFixed(2));
    document.body.style.setProperty("--my", y.toFixed(2));
});


/* SWITCH TO SIGN UP */

showSignup.addEventListener("click", () => {

    loginBox.classList.remove("active");
    signupBox.classList.add("active");

    loginBox.style.opacity = "0";
    loginBox.style.pointerEvents = "none";
    loginBox.style.transform = "translateX(-30px) scale(0.98)";

    signupBox.style.opacity = "1";
    signupBox.style.pointerEvents = "auto";
    signupBox.style.transform = "translateX(0) scale(1)";

});


/* SWITCH TO LOGIN */

showLogin.addEventListener("click", () => {

    signupBox.classList.remove("active");
    loginBox.classList.add("active");

    signupBox.style.opacity = "0";
    signupBox.style.pointerEvents = "none";
    signupBox.style.transform = "translateX(30px) scale(0.98)";

    loginBox.style.opacity = "1";
    loginBox.style.pointerEvents = "auto";
    loginBox.style.transform = "translateX(0) scale(1)";

});


/* SHOW MESSAGE */

function showMessage(text) {

    message.textContent = text;

    message.classList.add("show");

    setTimeout(() => {
        message.classList.remove("show");
    }, 6000);
}

async function showButtonLoading(button, loadingText, onComplete) {
    const originalText = button.textContent.trim();
    const isSignup = button.closest("#signupForm") !== null;

    button.textContent = loadingText;
    button.disabled = true;
    button.setAttribute("aria-busy", "true");
    button.classList.add("is-loading");
    if (isSignup) {
        button.classList.add("is-signing-up");
    }

    try {
        await onComplete();
    } catch (error) {
        showMessage(error.message || "The request could not be completed.");
    } finally {
        button.textContent = originalText;
        button.disabled = false;
        button.removeAttribute("aria-busy");
        button.classList.remove("is-loading");
        button.classList.remove("is-signing-up");
    }
}

async function continueWithAccount(user, openLoginDoor = false) {
    if (adminPortal && user.role !== "Admin") {
        showMessage("This account does not have administrator access.");
        return false;
    }
    if (user.role === "User" && !(await settleBirthDate())) {
        return false;
    }

    const profile = {
        name: user.display_name || user.username,
        email: user.email,
        photoData: ""
    };
    try {
        const savedProfile = JSON.parse(localStorage.getItem("test-site-profile") || "null");
        const savedPhoto = JSON.parse(localStorage.getItem(profilePhotoStorageKey) || "null");
        const sameEmail = typeof savedProfile?.email === "string" &&
            typeof profile.email === "string" &&
            savedProfile.email.trim().toLowerCase() === profile.email.trim().toLowerCase();
        if (sameEmail && typeof savedProfile.photoData === "string" &&
            /^data:image\/jpeg;base64,/.test(savedProfile.photoData)) {
            profile.photoData = savedProfile.photoData;
        } else if (
            typeof savedPhoto?.email === "string" &&
            typeof profile.email === "string" &&
            savedPhoto.email.trim().toLowerCase() === profile.email.trim().toLowerCase() &&
            typeof savedPhoto.photoData === "string" &&
            /^data:image\/jpeg;base64,/.test(savedPhoto.photoData)
        ) {
            profile.photoData = savedPhoto.photoData;
        }
    } catch (error) {
        console.warn("Could not restore the saved profile photo.", error);
    }
    const destination =
        adminPortal || user.role === "Admin" || user.role.endsWith("Personnel")
            ? "admin"
            : "reservation";
    if (destination === "reservation") {
        localStorage.setItem("test-site-profile", JSON.stringify(profile));
        localStorage.removeItem(profilePhotoStorageKey);
    }
    if (openLoginDoor) {
        document.body.classList.add("login-door-opening");
        const doorDuration = window.matchMedia("(prefers-reduced-motion: reduce)").matches
            ? 20
            : 1050;
        await new Promise((resolve) => window.setTimeout(resolve, doorDuration));
    }
    if (destination === "admin") {
        sessionStorage.removeItem("nexora-welcome");
        window.location.replace(new URL("../../CENTRAL CHANNEL/admin.html", window.location.href).href);
        return true;
    }
    sessionStorage.setItem("nexora-welcome", JSON.stringify({
        username: profile.name,
        name: profile.name,
        email: profile.email,
        destination
    }));
    window.location.replace(new URL("welcome.html", window.location.href).href);
    return true;
}

const consentCancelledMessage =
    "You need to accept the Terms of Service and Privacy Policy to continue. Nothing was submitted.";

/* A code-based sign-in can return a session before consent is recorded; the API
   refuses that session until the customer accepts, so finish it here or sign out. */
async function settleSessionConsent(user, source) {
    if (!user.consentRequired) {
        return true;
    }
    const consent = await window.NexoraConsent.open({ flow: "login" });
    if (!consent) {
        await window.ReservationAPI.logout().catch(() => {});
        showMessage(consentCancelledMessage);
        return false;
    }
    await window.ReservationAPI.acceptPolicies(consent, source);
    delete user.consentRequired;
    return true;
}

/* Customers who signed up before age checks existed are asked once, at their next
   sign-in. The server records the date and works out eligibility from it. */
async function settleBirthDate() {
    let status;
    try {
        status = await window.ReservationAPI.verificationStatus();
    } catch (error) {
        // An API without age checks has nothing to ask for.
        if (error.status === 404) {
            return true;
        }
        throw error;
    }
    if (status.birthDate) {
        return true;
    }
    const saved = await window.NexoraBirthDate.open({
        save: (birthDate) => window.ReservationAPI.setBirthDate(birthDate),
    });
    if (saved) {
        return true;
    }
    await window.ReservationAPI.logout().catch(() => {});
    showMessage("You need to add your date of birth to continue, so you have been signed out.");
    return false;
}

if (adminPortal) {
    document.title = "Admin sign in | Central Channel";
    document.querySelector(".top-bar .title").textContent = "Administrator Portal";
    document.querySelector(".login-box h1").textContent = "Admin sign in";
    document.querySelector(".login-box .subtitle").textContent = "Sign in with an administrator account";
    document.querySelector(".login-box .switch").hidden = true;
    document.getElementById("landingLink").hidden = true;
    signupBox.hidden = true;

    const adminLoginReason = new URLSearchParams(window.location.search).get("reason");
    if (adminLoginReason === "role") {
        showMessage("That account does not have administrator access. Sign in with the Admin account.");
    } else if (adminLoginReason === "switch") {
        showMessage("Signed out. Sign in with another administrator account.");
    } else if (adminLoginReason === "switch-error") {
        showMessage("Your local session was cleared, but server sign-out could not be confirmed. Check your connection before continuing.");
    }
}

/* LOGIN */

loginForm.addEventListener("submit", (event) => {

    event.preventDefault();
    const username = document.getElementById("loginUsername").value;
    const password = document.getElementById("loginPassword").value;

    showButtonLoading(
        loginForm.querySelector("button[type='submit']"),
        "Logging in...",
        async () => {
            const credentials = { username, password };
            let user;
            try {
                user = await window.ReservationAPI.login(credentials, { adminOnly: adminPortal });
            } catch (error) {
                if (error.code !== "consent_required") {
                    throw error;
                }
                // Only customer accounts are asked for consent, so this cannot be an administrator.
                if (adminPortal) {
                    throw new Error("This account does not have administrator access.");
                }
                const consent = await window.NexoraConsent.open({ flow: "login", missing: error.missing });
                if (!consent) {
                    document.getElementById("loginPassword").value = "";
                    showMessage(consentCancelledMessage);
                    return;
                }
                user = await window.ReservationAPI.login({ ...credentials, consent }, { adminOnly: adminPortal });
            }
            await continueWithAccount(user, true);
        }
    );

});

document.getElementById("forgotPassword").addEventListener("click", () => {
    loginForm.hidden = true;
    passwordRecoveryForm.hidden = false;
    passwordResetForm.hidden = true;
    loginBox.querySelector("h1").textContent = "Reset your password";
    loginBox.querySelector(".subtitle").textContent =
        "Enter your account email and we will send a recovery code.";
    document.getElementById("recoveryEmail").focus();
});

document.getElementById("recoveryBackToLogin").addEventListener("click", () => {
    passwordRecoveryForm.hidden = true;
    loginForm.hidden = false;
    loginBox.querySelector("h1").textContent = "Welcome Back";
    loginBox.querySelector(".subtitle").textContent =
        "Sign in to manage your stays and parking.";
});

passwordRecoveryForm.addEventListener("submit", (event) => {
    event.preventDefault();
    const email = document.getElementById("recoveryEmail").value.trim().toLowerCase();
    showButtonLoading(
        passwordRecoveryForm.querySelector("button[type='submit']"),
        "Sending code...",
        async () => {
            await window.ReservationAPI.sendPasswordRecovery(email);
            pendingRecoveryEmail = email;
            passwordRecoveryForm.hidden = true;
            passwordResetForm.hidden = false;
            loginBox.querySelector("h1").textContent = "Check your email";
            loginBox.querySelector(".subtitle").textContent =
                `If an active account exists, a recovery code was sent to ${pendingRecoveryEmail}.`;
            document.getElementById("recoveryCode").focus();
        }
    );
});

document.getElementById("resetBackToRecovery").addEventListener("click", () => {
    passwordResetForm.hidden = true;
    passwordRecoveryForm.hidden = false;
    loginBox.querySelector("h1").textContent = "Reset your password";
    loginBox.querySelector(".subtitle").textContent =
        "Enter your account email and we will send a recovery code.";
    document.getElementById("recoveryEmail").focus();
});

passwordResetForm.addEventListener("submit", (event) => {
    event.preventDefault();
    const password = document.getElementById("newPassword").value;
    const confirmation = document.getElementById("confirmNewPassword").value;
    if (password !== confirmation) {
        showMessage("Passwords do not match.");
        return;
    }

    showButtonLoading(
        passwordResetForm.querySelector("button[type='submit']"),
        "Updating password...",
        async () => {
            await window.ReservationAPI.resetPassword({
                email: pendingRecoveryEmail,
                token: document.getElementById("recoveryCode").value.trim(),
                password,
            });
            document.getElementById("loginUsername").value = pendingRecoveryEmail;
            document.getElementById("loginPassword").value = "";
            passwordResetForm.reset();
            pendingRecoveryEmail = "";
            passwordResetForm.hidden = true;
            loginForm.hidden = false;
            loginBox.querySelector("h1").textContent = "Password updated";
            loginBox.querySelector(".subtitle").textContent =
                "Sign in using your new password.";
            showMessage("Your password has been updated. Please sign in.");
        }
    );
});


/* SIGN UP */

signupForm.addEventListener("submit", (event) => {

    event.preventDefault();

    const fullName = fullNameField.value;
    const username = document.getElementById("signupUsername").value;
    const email = document.getElementById("signupEmail").value;
    const password =
        document.getElementById("signupPassword").value;

    const confirmPassword =
        document.getElementById("confirmPassword").value;
    const birthDate = birthDateField.value;


    /* CHECK PASSWORD */

    if (password !== confirmPassword) {

        showMessage("Passwords do not match.");

        return;
    }


    /* CHECK AGE (the server checks again and decides) */

    if (!birthDate || birthDate > localToday() || birthDate < "1900-01-01") {
        showMessage("Enter a valid date of birth.");
        birthDateField.focus();
        return;
    }
    if (window.NexoraBirthDate.ageOn(birthDate, localToday()) < 18) {
        showMessage("You must be 18 or older to create a NEXORA account.");
        birthDateField.focus();
        return;
    }


    showButtonLoading(
        signupForm.querySelector("button[type='submit']"),
        "Creating account...",
        async () => {
            // Kept for this page only, so correcting a rejected field does not mean reading both documents again.
            signupConsent = signupConsent || await window.NexoraConsent.open({ flow: "signup" });
            if (!signupConsent) {
                showMessage(consentCancelledMessage);
                return;
            }
            let result;
            try {
                result = await window.ReservationAPI.register({
                    username,
                    displayName: fullName,
                    email,
                    password,
                    birthDate,
                    consent: signupConsent
                });
            } catch (error) {
                if (error.code === "consent_invalid") {
                    signupConsent = null;
                }
                throw error;
            }
            if (result.token) {
                await continueWithAccount(result.user);
                return;
            }
            if (!result.requiresEmailConfirmation) {
                throw new Error("Account creation did not return a confirmation step or sign-in session. Please try again.");
            }
            pendingVerificationEmail = email.trim().toLowerCase();
            signupForm.hidden = true;
            verificationForm.hidden = false;
            signupBox.querySelector("h1").textContent = "Check your email";
            signupBox.querySelector(".subtitle").textContent =
                `Enter the confirmation code sent to ${pendingVerificationEmail}.`;
            document.getElementById("verificationCode").focus();
        }
    );

});

verificationForm.addEventListener("submit", (event) => {
    event.preventDefault();
    const code = document.getElementById("verificationCode").value.trim();
    showButtonLoading(
        verificationForm.querySelector("button[type='submit']"),
        "Verifying...",
        async () => {
            const user = await window.ReservationAPI.verifyEmail({
                email: pendingVerificationEmail,
                token: code,
            });
            if (await settleSessionConsent(user, "email-verification")) {
                await continueWithAccount(user);
            }
        }
    );
});

document.getElementById("resendVerification").addEventListener("click", () => {
    const button = document.getElementById("resendVerification");
    showButtonLoading(button, "Sending...", async () => {
        await window.ReservationAPI.resendEmailConfirmation(pendingVerificationEmail);
        showMessage("If the account is awaiting confirmation, a new code has been sent.");
    });
});

document.getElementById("verificationLogin").addEventListener("click", () => {
    showLogin.click();
});

if (!adminPortal && new URLSearchParams(window.location.search).get("mode") === "signup") {
    showSignup.click();
}