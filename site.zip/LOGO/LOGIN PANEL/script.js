const loginBox = document.querySelector(".login-box");
const signupBox = document.querySelector(".signup-box");

const showSignup = document.getElementById("showSignup");
const showLogin = document.getElementById("showLogin");

const loginForm = document.getElementById("loginForm");
const loginVerificationForm = document.getElementById("loginVerificationForm");
const signupForm = document.getElementById("signupForm");
const verificationForm = document.getElementById("verificationForm");
const passwordRecoveryForm = document.getElementById("passwordRecoveryForm");
const passwordResetForm = document.getElementById("passwordResetForm");
const emailCodeForm = document.getElementById("emailCodeForm");

const message = document.getElementById("message");
const adminPortal = new URLSearchParams(window.location.search).get("portal") === "admin";
const usernameFields = [document.getElementById("signupUsername")];
const disallowedUsernameCharacters = /[^A-Za-z0-9_@*]/g;
const fullNameField = document.getElementById("signupFullName");
const birthDateField = document.getElementById("signupBirthDate");
const localToday = () => {
    const now = new Date();
    return `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, "0")}-${String(now.getDate()).padStart(2, "0")}`;
};
birthDateField.max = localToday();
const passwordFields = [
    document.getElementById("signupPassword"),
    document.getElementById("confirmPassword"),
    document.getElementById("newPassword"),
    document.getElementById("confirmNewPassword")
].filter(Boolean);
const profilePhotoStorageKey = "nexora-profile-photo";
let pendingVerificationEmail = "";
let pendingLoginVerificationEmail = "";
let pendingRecoveryEmail = "";
let pendingCodeEmail = "";
let signupConsent = null;

function restrictInputCharacters(field, disallowedCharacters) {
    field.addEventListener("input", () => {
        const cursor = field.selectionStart;
        const cleanPrefix = field.value.slice(0, cursor).replace(disallowedCharacters, "");
        field.value = field.value.replace(disallowedCharacters, "");
        field.setSelectionRange(cleanPrefix.length, cleanPrefix.length);
    });
}

usernameFields.forEach((field) => {
    restrictInputCharacters(field, disallowedUsernameCharacters);
});
restrictInputCharacters(fullNameField, /[^A-Za-z ]/g);
passwordFields.forEach((field) => restrictInputCharacters(field, /[^A-Za-z0-9#*_]/g));
window.addEventListener("pointermove", (event) => {
    const x = (event.clientX / window.innerWidth) * 100;
    const y = (event.clientY / window.innerHeight) * 100;

    document.body.style.setProperty("--mx", x.toFixed(2));
    document.body.style.setProperty("--my", y.toFixed(2));
});

// The free-tier API sleeps when idle; wake it now so it is ready by the time a form is submitted.
window.ReservationAPI.serviceStatus().catch(() => {});


/* SWITCH TO SIGN UP */

showSignup.addEventListener("click", () => {

    loginBox.classList.remove("active");
    signupBox.classList.add("active");

    loginBox.style.opacity = "0";
    loginBox.style.pointerEvents = "none";
    loginBox.style.transform = "translateX(-30px) scale(0.98)";

    signupBox.style.opacity = "1";
    signupBox.style.pointerEvents = "auto";
    signupBox.style.transform = "translateX(0) scale(1)";

});


/* SWITCH TO LOGIN */

showLogin.addEventListener("click", () => {

    signupBox.classList.remove("active");
    loginBox.classList.add("active");

    signupBox.style.opacity = "0";
    signupBox.style.pointerEvents = "none";
    signupBox.style.transform = "translateX(30px) scale(0.98)";

    loginBox.style.opacity = "1";
    loginBox.style.pointerEvents = "auto";
    loginBox.style.transform = "translateX(0) scale(1)";

});


/* SHOW MESSAGE */

function showMessage(text) {

    message.textContent = text;

    message.classList.add("show");

    setTimeout(() => {
        message.classList.remove("show");
    }, 6000);
}

async function showButtonLoading(button, loadingText, onComplete) {
    const originalText = button.textContent.trim();
    const isSignup = button.closest("#signupForm") !== null;

    button.textContent = loadingText;
    button.disabled = true;
    button.setAttribute("aria-busy", "true");
    button.classList.add("is-loading");
    if (isSignup) {
        button.classList.add("is-signing-up");
    }

    try {
        await onComplete();
    } catch (error) {
        showMessage(error.message || "The request could not be completed.");
    } finally {
        button.textContent = originalText;
        button.disabled = false;
        button.removeAttribute("aria-busy");
        button.classList.remove("is-loading");
        button.classList.remove("is-signing-up");
    }
}

async function continueWithAccount(user, openLoginDoor = false) {
    if (adminPortal && !addingAccount && user.role !== "Admin") {
        showMessage("This account does not have administrator access.");
        return false;
    }
    if (user.role === "User" && !(await settleBirthDate())) {
        return false;
    }

    const profile = {
        name: user.display_name || user.username,
        email: user.email,
        photoData: ""
    };
    try {
        const savedProfile = JSON.parse(localStorage.getItem("test-site-profile") || "null");
        const savedPhoto = JSON.parse(localStorage.getItem(profilePhotoStorageKey) || "null");
        const sameEmail = typeof savedProfile?.email === "string" &&
            typeof profile.email === "string" &&
            savedProfile.email.trim().toLowerCase() === profile.email.trim().toLowerCase();
        if (sameEmail && typeof savedProfile.photoData === "string" &&
            /^data:image\/jpeg;base64,/.test(savedProfile.photoData)) {
            profile.photoData = savedProfile.photoData;
        } else if (
            typeof savedPhoto?.email === "string" &&
            typeof profile.email === "string" &&
            savedPhoto.email.trim().toLowerCase() === profile.email.trim().toLowerCase() &&
            typeof savedPhoto.photoData === "string" &&
            /^data:image\/jpeg;base64,/.test(savedPhoto.photoData)
        ) {
            profile.photoData = savedPhoto.photoData;
        }
    } catch (error) {
        console.warn("Could not restore the saved profile photo.", error);
    }
    // Only routing: each dashboard asks the server for the account's role before showing anything.
    const destination =
        adminPortal || user.role === "Admin"
            ? "admin"
            : user.role.endsWith("Personnel")
                ? "personnel"
                : "reservation";
    if (destination === "reservation") {
        localStorage.setItem("test-site-profile", JSON.stringify(profile));
        localStorage.removeItem(profilePhotoStorageKey);
    }
    if (openLoginDoor) {
        document.body.classList.add("login-door-opening");
        const doorDuration = window.matchMedia("(prefers-reduced-motion: reduce)").matches
            ? 20
            : 1050;
        await new Promise((resolve) => window.setTimeout(resolve, doorDuration));
    }
    if (destination === "admin" || destination === "personnel") {
        sessionStorage.removeItem("nexora-welcome");
        window.location.replace(new URL(`../../CENTRAL CHANNEL/${destination}.html`, window.location.href).href);
        return true;
    }
    sessionStorage.setItem("nexora-welcome", JSON.stringify({
        username: profile.name,
        name: profile.name,
        email: profile.email,
        destination
    }));
    window.location.replace(new URL("welcome.html", window.location.href).href);
    return true;
}

const consentCancelledMessage =
    "You need to accept the Terms of Service and Privacy Policy to continue. Nothing was submitted.";

/* A code-based sign-in can return a session before consent is recorded; the API
   refuses that session until the customer accepts, so finish it here or sign out. */
async function settleSessionConsent(user, source) {
    if (!user.consentRequired) {
        return true;
    }
    const consent = await window.NexoraConsent.open({ flow: "login" });
    if (!consent) {
        await window.ReservationAPI.logout().catch(() => {});
        showMessage(consentCancelledMessage);
        return false;
    }
    await window.ReservationAPI.acceptPolicies(consent, source);
    delete user.consentRequired;
    return true;
}

/* Customers who signed up before age checks existed are asked once, at their next
   sign-in. The server records the date and works out eligibility from it. */
async function settleBirthDate() {
    let status;
    try {
        status = await window.ReservationAPI.verificationStatus();
    } catch (error) {
        // An API without age checks has nothing to ask for.
        if (error.status === 404) {
            return true;
        }
        throw error;
    }
    if (status.birthDate) {
        return true;
    }
    const saved = await window.NexoraBirthDate.open({
        save: (birthDate) => window.ReservationAPI.setBirthDate(birthDate),
    });
    if (saved) {
        return true;
    }
    await window.ReservationAPI.logout().catch(() => {});
    showMessage("You need to add your date of birth to continue, so you have been signed out.");
    return false;
}

if (adminPortal) {
    document.title = "Admin sign in | Central Channel";
    document.querySelector(".top-bar .title").textContent = "Administrator Portal";
    document.querySelector(".login-box h1").textContent = "Admin sign in";
    document.querySelector(".login-box .subtitle").textContent = "Sign in with an administrator account";
    document.getElementById("showSignup").closest(".switch").hidden = true;
    document.getElementById("landingLink").hidden = true;
    signupBox.hidden = true;

    const adminLoginReason = new URLSearchParams(window.location.search).get("reason");
    if (adminLoginReason === "role") {
        showMessage("That account does not have administrator access. Sign in with the Admin account.");
    } else if (adminLoginReason === "switch") {
        showMessage("Signed out. Sign in with another administrator account.");
    } else if (adminLoginReason === "switch-error") {
        showMessage("Your local session was cleared, but server sign-out could not be confirmed. Check your connection before continuing.");
    } else if (adminLoginReason === "add-account") {
        document.querySelector(".login-box h1").textContent = "Add an account";
        document.querySelector(".login-box .subtitle").textContent =
            "Sign in with another administrator or staff account. Your other accounts stay saved on this device.";
    }
}
// Adding an account to the switcher accepts department staff as well as administrators.
const addingAccount = adminPortal && new URLSearchParams(window.location.search).get("reason") === "add-account";
const loginOptions = addingAccount ? { staffOnly: true } : { adminOnly: adminPortal };

/* LOGIN */

loginForm.addEventListener("submit", (event) => {

    event.preventDefault();
    const username = document.getElementById("loginUsername").value;
    const password = document.getElementById("loginPassword").value;

    showButtonLoading(
        loginForm.querySelector("button[type='submit']"),
        "Logging in...",
        async () => {
            const credentials = { username, password };
            let user;
            try {
                user = await window.ReservationAPI.login(credentials, loginOptions);
            } catch (error) {
                if (error.code === "email_not_confirmed") {
                    const email = username.trim().toLowerCase();
                    if (!emailPattern.test(email)) {
                        throw new Error("This email address hasn't been verified. Enter your email address to send a confirmation code.");
                    }
                    pendingLoginVerificationEmail = email;
                    document.getElementById("sendLoginVerification").hidden = false;
                    showMessage("Your email isn't verified yet. Send a confirmation code to continue.");
                    return;
                }
                if (error.code !== "consent_required") {
                    throw error;
                }
                // Only customer accounts are asked for consent, so this cannot be an administrator.
                if (adminPortal) {
                    throw new Error("This account does not have administrator access.");
                }
                const consent = await window.NexoraConsent.open({ flow: "login", missing: error.missing });
                if (!consent) {
                    document.getElementById("loginPassword").value = "";
                    showMessage(consentCancelledMessage);
                    return;
                }
                user = await window.ReservationAPI.login({ ...credentials, consent }, loginOptions);
            }
            await continueWithAccount(user, true);
        }
    );

});

/* SIGN IN WITH AN EMAIL CODE */

const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

function showLoginForm() {
    loginVerificationForm.hidden = true;
    emailCodeForm.hidden = true;
    loginForm.hidden = false;
    updateLoginVerificationAction();
    loginBox.querySelector("h1").textContent = adminPortal ? "Admin sign in" : "Welcome Back";
    loginBox.querySelector(".subtitle").textContent = adminPortal
        ? "Sign in with an administrator account"
        : "Sign in to manage your stays and parking.";
}

function updateLoginVerificationAction() {
    const email = document.getElementById("loginUsername").value.trim().toLowerCase();
    pendingLoginVerificationEmail = emailPattern.test(email) ? email : "";
    document.getElementById("sendLoginVerification").hidden = !pendingLoginVerificationEmail;
}

document.getElementById("loginUsername").addEventListener("input", () => {
    updateLoginVerificationAction();
});

document.getElementById("sendLoginVerification").addEventListener("click", () => {
    const email = pendingLoginVerificationEmail;
    if (!email || !emailPattern.test(email)) {
        showMessage("Enter the email address for the account that needs verification.");
        return;
    }
    showButtonLoading(document.getElementById("sendLoginVerification"), "Sending code...", async () => {
        await window.ReservationAPI.resendEmailConfirmation(email);
        loginForm.hidden = true;
        emailCodeForm.hidden = true;
        loginVerificationForm.hidden = false;
        loginVerificationForm.reset();
        loginBox.querySelector("h1").textContent = "Verify your email";
        loginBox.querySelector(".subtitle").textContent =
            `Enter the confirmation code sent to ${email}.`;
        document.getElementById("loginVerificationCode").focus();
    });
});

loginVerificationForm.addEventListener("submit", (event) => {
    event.preventDefault();
    const token = document.getElementById("loginVerificationCode").value.trim();
    showButtonLoading(
        loginVerificationForm.querySelector("button[type='submit']"),
        "Verifying...",
        async () => {
            const user = await window.ReservationAPI.verifyEmail(
                { email: pendingLoginVerificationEmail, token },
                loginOptions
            );
            if (await settleSessionConsent(user, "email-verification")) {
                await continueWithAccount(user, true);
            }
        }
    );
});

document.getElementById("resendLoginVerification").addEventListener("click", () => {
    showButtonLoading(document.getElementById("resendLoginVerification"), "Sending...", async () => {
        await window.ReservationAPI.resendEmailConfirmation(pendingLoginVerificationEmail);
        showMessage("If the account is awaiting confirmation, a new code has been sent.");
    });
});

document.getElementById("loginVerificationBackToLogin").addEventListener("click", showLoginForm);

document.getElementById("receiveCode").addEventListener("click", () => {
    const emailField = document.getElementById("loginUsername");
    const email = emailField.value.trim().toLowerCase();
    if (!emailPattern.test(email)) {
        showMessage("Enter your account email address to receive a sign-in code.");
        emailField.focus();
        return;
    }
    showButtonLoading(document.getElementById("receiveCode"), "Sending code...", async () => {
        await window.ReservationAPI.sendEmailOtp(email);
        pendingCodeEmail = email;
        loginForm.hidden = true;
        emailCodeForm.hidden = false;
        emailCodeForm.reset();
        loginBox.querySelector("h1").textContent = "Check your email";
        loginBox.querySelector(".subtitle").textContent =
            `If an active account uses ${pendingCodeEmail}, a 6-digit sign-in code was sent to it.`;
        document.getElementById("emailCode").focus();
    });
});

emailCodeForm.addEventListener("submit", (event) => {
    event.preventDefault();
    const code = document.getElementById("emailCode").value.trim();
    showButtonLoading(
        emailCodeForm.querySelector("button[type='submit']"),
        "Verifying...",
        async () => {
            const user = await window.ReservationAPI.verifyEmailOtp(
                { email: pendingCodeEmail, token: code },
                loginOptions
            );
            if (await settleSessionConsent(user, "email-otp")) {
                await continueWithAccount(user, true);
            }
        }
    );
});

document.getElementById("resendEmailCode").addEventListener("click", () => {
    showButtonLoading(document.getElementById("resendEmailCode"), "Sending...", async () => {
        await window.ReservationAPI.sendEmailOtp(pendingCodeEmail);
        showMessage("If an active account uses that email, a new sign-in code has been sent.");
    });
});

document.getElementById("emailCodeBackToLogin").addEventListener("click", showLoginForm);

/* FORGOT PASSWORD: email -> emailed recovery code -> new password.
   Supabase Auth issues and checks the code. Verifying it opens a short recovery session
   that the server requires before it accepts a new password; the page keeps that session
   in memory only, so reloading or leaving the page means starting again. */

const recoveryCodeForm = document.getElementById("recoveryCodeForm");
const recoveryCodeInputs = document.getElementById("recoveryCodeInputs");
const recoveryDigits = [...recoveryCodeInputs.querySelectorAll("input")];
const resendRecoveryButton = document.getElementById("resendRecoveryCode");
const newPasswordField = document.getElementById("newPassword");
const confirmNewPasswordField = document.getElementById("confirmNewPassword");
const RESEND_WAIT_SECONDS = 60;
const NEW_PASSWORD_MIN_LENGTH = 12;
let recoverySession = null;
let resendCountdown = 0;

const recoverySteps = {
    email: [passwordRecoveryForm, "Reset your password",
        () => "Enter your account email and we will send you a 6-digit recovery code."],
    code: [recoveryCodeForm, "Check your email",
        () => `If an active NEXORA account uses ${pendingRecoveryEmail}, we sent it a 6-digit code.`],
    password: [passwordResetForm, "Choose a new password",
        () => "Your code was verified. Set a new password for your account."],
};

function showRecoveryStep(step) {
    loginForm.hidden = true;
    Object.entries(recoverySteps).forEach(([name, [form]]) => { form.hidden = name !== step; });
    const [form, title, subtitle] = recoverySteps[step];
    loginBox.querySelector("h1").textContent = title;
    loginBox.querySelector(".subtitle").textContent = subtitle();
    form.querySelector("input:not([type=hidden])").focus();
}

function clearRecovery() {
    recoverySession = null;
    pendingRecoveryEmail = "";
    window.clearInterval(resendCountdown);
    passwordRecoveryForm.reset();
    clearRecoveryCode();
    passwordResetForm.reset();
    updatePasswordFeedback();
    passwordResetForm.querySelectorAll(".reveal-password").forEach((button) => setPasswordVisible(button, false));
}

function leaveRecovery() {
    clearRecovery();
    Object.values(recoverySteps).forEach(([form]) => { form.hidden = true; });
    showLoginForm();
}

function startResendCountdown(seconds = RESEND_WAIT_SECONDS) {
    window.clearInterval(resendCountdown);
    let remaining = seconds;
    const tick = () => {
        resendRecoveryButton.disabled = remaining > 0;
        resendRecoveryButton.textContent = remaining > 0 ? `Resend code in ${remaining}s` : "Resend code";
        if (remaining-- <= 0) {
            window.clearInterval(resendCountdown);
        }
    };
    tick();
    resendCountdown = window.setInterval(tick, 1000);
}

document.getElementById("forgotPassword").addEventListener("click", () => {
    clearRecovery();
    const typed = document.getElementById("loginUsername").value.trim().toLowerCase();
    if (emailPattern.test(typed)) {
        document.getElementById("recoveryEmail").value = typed;
    }
    showRecoveryStep("email");
});

document.getElementById("recoveryBackToLogin").addEventListener("click", leaveRecovery);

passwordRecoveryForm.addEventListener("submit", (event) => {
    event.preventDefault();
    const email = document.getElementById("recoveryEmail").value.trim().toLowerCase();
    if (!emailPattern.test(email)) {
        showMessage("Enter a valid email address, like name@example.com.");
        document.getElementById("recoveryEmail").focus();
        return;
    }
    showButtonLoading(
        passwordRecoveryForm.querySelector("button[type='submit']"),
        "Sending code...",
        async () => {
            // The reply is the same whether or not an account uses this email.
            await window.ReservationAPI.sendPasswordRecovery(email);
            pendingRecoveryEmail = email;
            clearRecoveryCode();
            showRecoveryStep("code");
            startResendCountdown();
            showMessage("Check your inbox and spam folder for the NEXORA recovery code.");
        }
    );
});

/* Six single-digit boxes that behave like one field: typing moves forward, Backspace
   moves back, and pasting or autofilling the whole code fills every box. */

const recoveryCodeValue = () => recoveryDigits.map((input) => input.value).join("");

function clearRecoveryCode() {
    recoveryDigits.forEach((input) => { input.value = ""; });
    recoveryCodeInputs.classList.remove("is-invalid");
}

function fillRecoveryCode(digits, start = 0) {
    [...digits.slice(0, recoveryDigits.length - start)].forEach((digit, offset) => {
        recoveryDigits[start + offset].value = digit;
    });
    (recoveryDigits.find((input) => !input.value) || recoveryDigits.at(-1)).focus();
    if (recoveryCodeValue().length === recoveryDigits.length) {
        recoveryCodeForm.requestSubmit();
    }
}

recoveryDigits.forEach((input, index) => {
    input.addEventListener("focus", () => input.select());
    input.addEventListener("input", () => {
        recoveryCodeInputs.classList.remove("is-invalid");
        const digits = input.value.replace(/\D/g, "");
        input.value = "";
        if (digits) {
            fillRecoveryCode(digits, index);
        }
    });
    input.addEventListener("paste", (event) => {
        event.preventDefault();
        const digits = (event.clipboardData?.getData("text") || "").replace(/\D/g, "");
        if (digits) {
            fillRecoveryCode(digits, digits.length >= recoveryDigits.length ? 0 : index);
        }
    });
    input.addEventListener("keydown", (event) => {
        if (event.key === "Backspace" && !input.value && index > 0) {
            event.preventDefault();
            recoveryDigits[index - 1].value = "";
            recoveryDigits[index - 1].focus();
        } else if (event.key === "ArrowLeft" && index > 0) {
            event.preventDefault();
            recoveryDigits[index - 1].focus();
        } else if (event.key === "ArrowRight" && index < recoveryDigits.length - 1) {
            event.preventDefault();
            recoveryDigits[index + 1].focus();
        }
    });
});

recoveryCodeForm.addEventListener("submit", (event) => {
    event.preventDefault();
    const button = recoveryCodeForm.querySelector("button[type='submit']");
    if (button.disabled) {
        return;
    }
    const token = recoveryCodeValue();
    if (!/^\d{6}$/.test(token)) {
        showMessage("Enter all 6 digits of the recovery code.");
        (recoveryDigits.find((input) => !input.value) || recoveryDigits[0]).focus();
        return;
    }
    showButtonLoading(button, "Verifying...", async () => {
        let result;
        try {
            result = await window.ReservationAPI.verifyRecoveryCode({ email: pendingRecoveryEmail, token });
        } catch (error) {
            clearRecoveryCode();
            recoveryCodeInputs.classList.add("is-invalid");
            recoveryDigits[0].focus();
            throw error;
        }
        recoverySession = {
            token: result.recoveryToken,
            expiresAt: Date.now() + Number(result.expiresInSeconds || 0) * 1000,
        };
        showRecoveryStep("password");
    });
});

resendRecoveryButton.addEventListener("click", async () => {
    if (resendRecoveryButton.disabled || !pendingRecoveryEmail) {
        return;
    }
    resendRecoveryButton.disabled = true;
    resendRecoveryButton.textContent = "Sending...";
    try {
        await window.ReservationAPI.sendPasswordRecovery(pendingRecoveryEmail);
        clearRecoveryCode();
        recoveryDigits[0].focus();
        showMessage("If an active account uses that email, a new recovery code has been sent. Earlier codes no longer work.");
        startResendCountdown();
    } catch (error) {
        showMessage(error.message || "A new code could not be sent. Please try again.");
        // A rate-limited request waits out the full countdown before trying again.
        startResendCountdown(error.status === 429 ? RESEND_WAIT_SECONDS : 0);
    }
});

document.getElementById("codeBackToRecovery").addEventListener("click", () => {
    const email = pendingRecoveryEmail;
    clearRecovery();
    document.getElementById("recoveryEmail").value = email;
    showRecoveryStep("email");
});

/* New password: show/hide, strength feedback and the rules the server enforces. */

function setPasswordVisible(button, visible) {
    document.getElementById(button.getAttribute("aria-controls")).type = visible ? "text" : "password";
    button.setAttribute("aria-pressed", String(visible));
    button.textContent = visible ? "Hide" : "Show";
    button.setAttribute("aria-label", visible ? "Hide password" : "Show password");
}

passwordResetForm.querySelectorAll(".reveal-password").forEach((button) => {
    setPasswordVisible(button, false);
    button.addEventListener("click", () => {
        setPasswordVisible(button, button.getAttribute("aria-pressed") !== "true");
    });
});

function newPasswordRules(password, confirmation) {
    return {
        length: password.length >= NEW_PASSWORD_MIN_LENGTH,
        case: /[a-z]/.test(password) && /[A-Z]/.test(password),
        number: /\d/.test(password),
        match: password.length > 0 && password === confirmation,
    };
}

function updatePasswordFeedback() {
    const password = newPasswordField.value;
    const rules = newPasswordRules(password, confirmNewPasswordField.value);
    passwordResetForm.querySelectorAll("[data-rule]").forEach((item) => {
        item.classList.toggle("met", rules[item.dataset.rule]);
    });
    const points = [rules.length, rules.case, rules.number, password.length >= 16, /[#*_]/.test(password)]
        .filter(Boolean).length;
    const level = !password ? 0 : !rules.length ? 1 : Math.min(4, Math.max(2, points - 1));
    const bar = document.getElementById("passwordStrengthBar");
    bar.style.width = `${level * 25}%`;
    bar.parentElement.dataset.level = String(level);
    const label = ["", "Too short", "Fair", "Good", "Strong"][level];
    document.getElementById("passwordStrengthLabel").textContent = label ? `Strength: ${label}` : "";
    return rules;
}

[newPasswordField, confirmNewPasswordField].forEach((field) => field.addEventListener("input", updatePasswordFeedback));

document.getElementById("resetBackToRecovery").addEventListener("click", () => {
    const email = pendingRecoveryEmail;
    clearRecovery();
    document.getElementById("recoveryEmail").value = email;
    showRecoveryStep("email");
});

passwordResetForm.addEventListener("submit", (event) => {
    event.preventDefault();
    const password = newPasswordField.value;
    const rules = updatePasswordFeedback();
    if (!recoverySession || Date.now() >= recoverySession.expiresAt) {
        recoverySession = null;
        passwordResetForm.reset();
        updatePasswordFeedback();
        clearRecoveryCode();
        showRecoveryStep("code");
        showMessage("Your password reset session has expired. Request a new code and try again.");
        return;
    }
    if (!rules.length || !rules.case || !rules.number) {
        showMessage(`Use at least ${NEW_PASSWORD_MIN_LENGTH} characters with upper- and lower-case letters and a number.`);
        newPasswordField.focus();
        return;
    }
    if (!rules.match) {
        showMessage("Passwords do not match.");
        confirmNewPasswordField.focus();
        return;
    }

    showButtonLoading(
        passwordResetForm.querySelector("button[type='submit']"),
        "Updating password...",
        async () => {
            try {
                await window.ReservationAPI.resetPassword({ recoveryToken: recoverySession.token, password });
            } catch (error) {
                // The server ended or refused the recovery session: a new code is needed.
                if (error.status === 401) {
                    recoverySession = null;
                    passwordResetForm.reset();
                    updatePasswordFeedback();
                    clearRecoveryCode();
                    showRecoveryStep("code");
                }
                throw error;
            }
            const email = pendingRecoveryEmail;
            leaveRecovery();
            document.getElementById("loginUsername").value = email;
            document.getElementById("loginPassword").value = "";
            updateLoginVerificationAction();
            loginBox.querySelector("h1").textContent = "Password updated";
            loginBox.querySelector(".subtitle").textContent =
                "Sign in using your new password. You were signed out on your other devices.";
            document.getElementById("loginPassword").focus();
            showMessage("Your password has been updated. Please sign in.");
        }
    );
});


/* SIGN UP */

signupForm.addEventListener("submit", (event) => {

    event.preventDefault();

    const fullName = fullNameField.value;
    const username = document.getElementById("signupUsername").value;
    const email = document.getElementById("signupEmail").value;
    const password =
        document.getElementById("signupPassword").value;

    const confirmPassword =
        document.getElementById("confirmPassword").value;
    const birthDate = birthDateField.value;


    /* CHECK PASSWORD */

    if (password !== confirmPassword) {

        showMessage("Passwords do not match.");

        return;
    }


    /* CHECK AGE (the server checks again and decides) */

    if (!birthDate || birthDate > localToday() || birthDate < "1900-01-01") {
        showMessage("Enter a valid date of birth.");
        birthDateField.focus();
        return;
    }
    if (window.NexoraBirthDate.ageOn(birthDate, localToday()) < 18) {
        showMessage("You must be 18 or older to create a NEXORA account.");
        birthDateField.focus();
        return;
    }


    showButtonLoading(
        signupForm.querySelector("button[type='submit']"),
        "Creating account...",
        async () => {
            // Kept for this page only, so correcting a rejected field does not mean reading both documents again.
            signupConsent = signupConsent || await window.NexoraConsent.open({ flow: "signup" });
            if (!signupConsent) {
                showMessage(consentCancelledMessage);
                return;
            }
            let result;
            try {
                result = await window.ReservationAPI.register({
                    username,
                    displayName: fullName,
                    email,
                    password,
                    birthDate,
                    consent: signupConsent
                });
            } catch (error) {
                if (error.code === "consent_invalid") {
                    signupConsent = null;
                }
                throw error;
            }
            if (result.token) {
                await continueWithAccount(result.user);
                return;
            }
            if (!result.requiresEmailConfirmation) {
                throw new Error("Account creation did not return a confirmation step or sign-in session. Please try again.");
            }
            pendingVerificationEmail = email.trim().toLowerCase();
            signupForm.hidden = true;
            verificationForm.hidden = false;
            signupBox.querySelector("h1").textContent = "Check your email";
            signupBox.querySelector(".subtitle").textContent =
                `Enter the confirmation code sent to ${pendingVerificationEmail}.`;
            document.getElementById("verificationCode").focus();
        }
    );

});

verificationForm.addEventListener("submit", (event) => {
    event.preventDefault();
    const code = document.getElementById("verificationCode").value.trim();
    showButtonLoading(
        verificationForm.querySelector("button[type='submit']"),
        "Verifying...",
        async () => {
            const user = await window.ReservationAPI.verifyEmail({
                email: pendingVerificationEmail,
                token: code,
            });
            if (await settleSessionConsent(user, "email-verification")) {
                await continueWithAccount(user);
            }
        }
    );
});

document.getElementById("resendVerification").addEventListener("click", () => {
    const button = document.getElementById("resendVerification");
    showButtonLoading(button, "Sending...", async () => {
        await window.ReservationAPI.resendEmailConfirmation(pendingVerificationEmail);
        showMessage("If the account is awaiting confirmation, a new code has been sent.");
    });
});

document.getElementById("verificationLogin").addEventListener("click", () => {
    showLogin.click();
});

if (!adminPortal && new URLSearchParams(window.location.search).get("mode") === "signup") {
    showSignup.click();
}