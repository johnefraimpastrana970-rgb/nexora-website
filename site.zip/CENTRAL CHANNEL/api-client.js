

(() => {
  const SESSION_KEYS = {
    customer: {
      token: "central-channel-user-session",
      refresh: "central-channel-user-refresh-session",
    },
    admin: {
      token: "central-channel-admin-session",
      refresh: "central-channel-admin-refresh-session",
    },
  };
  const path = decodeURIComponent(location.pathname).toLowerCase();
  // Administrators and department staff share the staff session; customers have their own.
  let activeScope = path.endsWith("/central channel/admin.html") ||
    path.endsWith("/central channel/personnel.html") ||
    new URLSearchParams(location.search).get("portal") === "admin"
    ? "admin"
    : "customer";
  const configuredBase =
    localStorage.getItem("nexora-central-api-base") ||
    window.CENTRAL_API_BASE ||
    window.APP_CONFIG?.apiBase;
  const offlineMode = localStorage.getItem("nexora-central-api-offline") === "true";
  const deployedApiBase = "https://nexora-reservation-api.onrender.com";
  const localHosts = new Set(["localhost", "127.0.0.1", "[::1]", "::1"]);
  const capacitorLocalhost =
    location.protocol === "https:" &&
    location.hostname === "localhost" &&
    !location.port;
  const localFrontend = location.protocol === "file:" ||
    (!capacitorLocalhost && localHosts.has(location.hostname) && location.port !== "8000");
  const githubPages = location.hostname.endsWith(".github.io");
  const defaultBase = localFrontend
    ? "http://127.0.0.1:8000"
    : githubPages || capacitorLocalhost
      ? deployedApiBase
      : location.origin;
  const base = offlineMode ? "" : (configuredBase || defaultBase).replace(/\/$/, "");
  let invalidApiBase = false;
  let invalidSupabaseBase = false;
  if (base) {
    try {
      const apiUrl = new URL(base);
      invalidApiBase = !["http:", "https:"].includes(apiUrl.protocol);
      invalidSupabaseBase = apiUrl.hostname.endsWith(".supabase.co");
    } catch {
      invalidApiBase = true;
    }
  }
  const encode = encodeURIComponent;
  let lastFailedRequestId = "";
  const activeKeys = () => SESSION_KEYS[activeScope];

  // Requests that meet an expired token share one refresh. Supabase refresh tokens are
  // single-use, so parallel refreshes would all fail but one and sign the person out.
  let refreshInFlight = null;
  function refreshSession() {
    if (!refreshInFlight) refreshInFlight = runRefresh().finally(() => { refreshInFlight = null; });
    return refreshInFlight;
  }
  // Set while the account switcher swaps sessions, so a page's polling cannot send one
  // account's requests with the other account's token.
  let switchingAccounts = false;
  const SAFE_READ_RETRIES = 2;
  const pause = (ms) => new Promise((resolve) => setTimeout(resolve, ms));
  const retryDelay = (attempt) => 800 * 2 ** attempt + Math.floor(Math.random() * 300);
  const apiError = (message, fields = {}) => Object.assign(new Error(message), { apiError: true }, fields);

  async function runRefresh() {
    const refreshToken = localStorage.getItem(activeKeys().refresh);
    if (!refreshToken) return false;
    try {
      const response = await fetch(`${base}/api/auth/refresh`, {
        method: "POST",
        headers: { "Accept": "application/json", "Content-Type": "application/json" },
        body: JSON.stringify({ refreshToken }),
      });
      const result = await response.json().catch(() => null);
      if (!response.ok || !result?.token) return false;
      localStorage.setItem(activeKeys().token, result.token);
      if (result.refreshToken) localStorage.setItem(activeKeys().refresh, result.refreshToken);
      return true;
    } catch {
      return false;
    }
  }

  async function request(path, options = {}, authOptions = {}) {
    const {
      canRefresh = true,
      preserveSessionOnUnauthorized = false,
      includeAuth = true,
      attempt = 0,
    } = authOptions;
    const isLoginRequest = path === "/api/auth/login";
    // Reads change nothing, so a brief network or database hiccup is retried before it is shown.
    const canRetryRead = (options.method || "GET").toUpperCase() === "GET" && attempt < SAFE_READ_RETRIES;
    const retryRead = async () => {
      await pause(retryDelay(attempt));
      return request(path, options, { ...authOptions, attempt: attempt + 1 });
    };
    if (switchingAccounts && path !== "/api/auth/me") {
      throw apiError("Switching accounts. This page will reload in a moment.", { code: "switching" });
    }
    if (!base) {
      throw new Error(
        "Reservation services are not connected to this website yet. GitHub Pages only hosts the website; the Central Channel API must be deployed separately. Use API connection settings after you have its HTTPS address.",
      );
    }
    if (invalidApiBase) {
      throw new Error(
        "The saved API address is invalid. Open API connection settings and enter the HTTPS address of the deployed Central Channel API.",
      );
    }
    if (invalidSupabaseBase) {
      throw new Error(
        "This is a Supabase project URL, not the Central Channel reservation API. Enter the HTTPS address of the deployed Central Channel service in API connection settings.",
      );
    }
    const headers = new Headers(options.headers || {});
    headers.set("Accept", "application/json");
    if (options.body !== undefined) headers.set("Content-Type", "application/json");
    const token = localStorage.getItem(activeKeys().token);
    if (token && includeAuth && !isLoginRequest) headers.set("Authorization", `Bearer ${token}`);
    let response;
    try {
      response = await fetch(`${base}${path}`, {
        ...options, headers,
        body: options.body === undefined ? undefined : JSON.stringify(options.body),
      });
    } catch {
      if (canRetryRead) return retryRead();
      const help = localFrontend
        ? " Start the backend with RUN_RESERVATION_SITE.bat and check its API URL."
        : " Check that the API server is running at this address.";
      throw apiError(`Cannot reach the reservation API at ${base}.${help}`);
    }
    const payload = response.status === 204 ? null : await response.json().catch(() => null);
    // The body's requestId also works cross-origin, where the header may not be readable.
    const requestId = payload?.requestId || response.headers.get("X-Request-ID") || "";
    if (canRetryRead && response.status >= 503 && payload?.retryable === true) return retryRead();
    if (!response.ok) lastFailedRequestId = requestId;
    if (response.status === 401 && canRefresh && !isLoginRequest && path !== "/api/auth/refresh") {
      // Another request may already have refreshed the session while this one was in flight.
      const current = localStorage.getItem(activeKeys().token);
      if ((current && current !== token) || await refreshSession()) {
        return request(path, options, { ...authOptions, canRefresh: false });
      }
    }
    if (!response.ok) {
      // Only the session this request used is cleared, never a newer one.
      if (response.status === 401 && !preserveSessionOnUnauthorized && !isLoginRequest
          && localStorage.getItem(activeKeys().token) === token) {
        localStorage.removeItem(activeKeys().token);
        localStorage.removeItem(activeKeys().refresh);
      }
      if (response.status === 401 && payload?.error === "Sign in to continue.") {
        throw apiError("Your session has expired. Sign in again to continue.", { status: 401 });
      }
      const errorMessage =
        response.status === 405
          ? "This address is serving website files, not the reservation API. Set API connection settings to the deployed Central Channel API HTTPS address."
          : response.status === 404 && githubPages
            ? "The reservation API was not found on GitHub Pages. Deploy the Central Channel backend separately and enter its HTTPS address in API connection settings."
            : response.status === 401 && !payload?.error
              ? "Your sign-in was not accepted. Sign in again, or check your username and password."
              : payload?.error || `Request failed (${response.status}).`;
      // Server faults carry a short reference that administrators can find in the error monitor.
      const error = apiError(response.status >= 500 && requestId
        ? `${errorMessage} (Reference ${requestId.slice(0, 8)})`
        : errorMessage);
      error.status = response.status;
      error.code = payload?.code || "";
      error.retryable = payload?.retryable === true;
      error.requestId = requestId;
      error.missing = Array.isArray(payload?.missing) ? payload.missing : [];
      error.services = Array.isArray(payload?.services) ? payload.services : [];
      // A signed-in customer whose accepted policy version is out of date: pages that
      // hold a session listen for this to show the renewal prompt.
      if (error.code === "consent_required" && !isLoginRequest) {
        window.dispatchEvent(new CustomEvent("nexora:consent-required", { detail: { missing: error.missing } }));
      }
      throw error;
    }
    return payload;
  }

  /* Accounts saved on this device for the account switcher. Each administrator or staff
     account signs in once with its own password; its session is then kept here so the
     person can switch between accounts without signing out. The server still checks every
     request against the account in use. Signing out of an account removes it. */
  const SAVED_ACCOUNTS_KEY = "nexora-saved-staff-accounts";
  const SAVED_PROFILE_FIELDS = ["id", "username", "displayName", "role", "department", "purpose", "importance"];
  function readSavedAccounts() {
    try {
      const saved = JSON.parse(localStorage.getItem(SAVED_ACCOUNTS_KEY));
      return saved && typeof saved === "object" && !Array.isArray(saved) ? saved : {};
    } catch {
      return {};
    }
  }
  function writeSavedAccounts(saved) {
    localStorage.setItem(SAVED_ACCOUNTS_KEY, JSON.stringify(saved));
  }
  let currentAccountId = "";
  // Copies the live session into the saved entry: a refresh may have replaced its tokens.
  function stashCurrentAccount() {
    const saved = readSavedAccounts();
    const token = localStorage.getItem(SESSION_KEYS.admin.token);
    if (!currentAccountId || !saved[currentAccountId] || !token) return saved;
    saved[currentAccountId].token = token;
    saved[currentAccountId].refresh = localStorage.getItem(SESSION_KEYS.admin.refresh) || "";
    writeSavedAccounts(saved);
    return saved;
  }
  function useSession(entry) {
    localStorage.setItem(SESSION_KEYS.admin.token, entry.token);
    if (entry.refresh) localStorage.setItem(SESSION_KEYS.admin.refresh, entry.refresh);
    else localStorage.removeItem(SESSION_KEYS.admin.refresh);
  }
  const panelUrl = (account) => account.role === "Admin" ? "admin.html" : "personnel.html";

  async function authenticate(path, credentials, options = {}) {
    const result = await request(path, { method: "POST", body: credentials });
    if (options.adminOnly && result.user?.role !== "Admin") {
      throw new Error("This account does not have administrator access.");
    }
    if (options.staffOnly && (!result.user?.role || result.user.role === "User")) {
      throw new Error("Only administrator and staff accounts can be added to the account switcher.");
    }
    if (!result.token) {
      const scope = result.user?.role === "User" ? "customer" : "admin";
      localStorage.removeItem(SESSION_KEYS[scope].token);
      localStorage.removeItem(SESSION_KEYS[scope].refresh);
      if (result.requiresEmailConfirmation) {
        throw new Error("Account created. Check your email to confirm it, then log in.");
      }
      throw new Error("Authentication succeeded without a session. Please try logging in.");
    }
    activeScope = result.user?.role === "User" ? "customer" : "admin";
    localStorage.setItem(activeKeys().token, result.token);
    if (result.refreshToken) localStorage.setItem(activeKeys().refresh, result.refreshToken);
    // Code-based sign-ins return a session that the API will not honour until the
    // customer accepts the current policies (see acceptPolicies).
    if (result.consentRequired) result.user.consentRequired = true;
    return result.user;
  }

  function newIdempotencyKey() {
    if (crypto.randomUUID) return crypto.randomUUID();
    return [...crypto.getRandomValues(new Uint8Array(16))].map((byte) => byte.toString(16).padStart(2, "0")).join("");
  }

  /* Browser crashes are reported to the error monitor so administrators see them.
     Only a fixed label for the kind of error and the page is sent: never the message,
     stack or address, which could contain personal data. Each kind is sent once per page. */
  const reportedClientErrors = new Set();
  function pageLabel() {
    const file = path.split("/").pop();
    if (file === "main.html") return "customer";
    if (file === "admin.html") return "admin";
    if (file === "personnel.html") return "personnel";
    if (file === "index.html") return path.includes("/login panel/") ? "login" : "other";
    if (["landing.html", "welcome.html"].includes(file)) return file.replace(".html", "");
    if (file === "api-settings.html") return "settings";
    return path.includes("/legal/") ? "legal" : "other";
  }
  function reportClientError(kind) {
    if (!base || invalidApiBase || invalidSupabaseBase || reportedClientErrors.has(kind)) return;
    reportedClientErrors.add(kind);
    fetch(`${base}/api/client-errors`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ kind, page: pageLabel() }),
      keepalive: true,
    }).catch((error) => console.warn("Could not report a page error to NEXORA.", error));
  }
  window.addEventListener("error", (event) => {
    // Errors from other sites' scripts (maps, fonts, CDNs) are not NEXORA's to fix.
    if (event.filename && event.filename.startsWith(location.origin)) reportClientError("script_error");
  });
  // A failed API call is already recorded by the server with its real cause; only other
  // rejections are page faults worth reporting.
  window.addEventListener("unhandledrejection", (event) => {
    if (!event.reason?.apiError) reportClientError("unhandled_rejection");
  });

  const queryString = (params = {}) => {
    const search = new URLSearchParams();
    Object.entries(params).forEach(([key, value]) => {
      if (value !== undefined && value !== null && value !== "") search.set(key, value);
    });
    const text = search.toString();
    return text ? `?${text}` : "";
  };

  window.ReservationAPI = {
    base,
    get tokenKey() { return activeKeys().token; },
    get refreshTokenKey() { return activeKeys().refresh; },
    clearSession: () => {
      localStorage.removeItem(activeKeys().token);
      localStorage.removeItem(activeKeys().refresh);
    },
    login: (credentials, options) => authenticate("/api/auth/login", credentials, options),
    register: async (details) => {
      const result = await request("/api/auth/register", { method: "POST", body: details });
      if (result.token) {
        if (!result.user) throw new Error("Account creation returned an incomplete session. Please contact support.");
        activeScope = result.user.role === "User" ? "customer" : "admin";
        localStorage.setItem(activeKeys().token, result.token);
        if (result.refreshToken) localStorage.setItem(activeKeys().refresh, result.refreshToken);
        else localStorage.removeItem(activeKeys().refresh);
      }
      return result;
    },
    verifyEmail: (credentials, options) => authenticate("/api/auth/verify-email", credentials, options),
    resendEmailConfirmation: (email) => request("/api/auth/resend-confirmation", {
      method: "POST",
      body: { email },
    }),
    sendEmailOtp: (email) => request("/api/auth/email-otp", {
      method: "POST",
      body: { email },
    }),
    verifyEmailOtp: (credentials, options) => authenticate("/api/auth/verify-email-otp", credentials, options),
    sendPasswordRecovery: (email) => request("/api/auth/password-recovery", {
      method: "POST",
      body: { email },
    }, {
      canRefresh: false,
      preserveSessionOnUnauthorized: true,
      includeAuth: false,
    }),
    // Returns a short-lived recovery session; callers keep it in memory, never in storage.
    verifyRecoveryCode: (credentials) => request("/api/auth/verify-recovery-code", {
      method: "POST",
      body: credentials,
    }, {
      canRefresh: false,
      preserveSessionOnUnauthorized: true,
      includeAuth: false,
    }),
    resetPassword: (credentials) => request("/api/auth/reset-password", {
      method: "POST",
      body: credentials,
    }, {
      canRefresh: false,
      preserveSessionOnUnauthorized: true,
      includeAuth: false,
    }),
    me: async () => (await request("/api/auth/me")).user,
    acceptPolicies: (consent, source = "renewal") => request("/api/legal/consent", {
      method: "POST",
      body: { consent, source },
    }),
    // Age, ID and driver's license checks. The server decides every status; these only ask.
    verificationStatus: () => request("/api/verification/status"),
    setBirthDate: (birthDate) => request("/api/verification/birth-date", { method: "PUT", body: { birthDate } }),
    submitIdentity: (details) => request("/api/verification/identity", { method: "POST", body: details }),
    useDemoLicense: () => request("/api/verification/license/demo", { method: "POST", body: {} }),
    verificationQueue: (status = "PENDING", kind = "") =>
      request(`/api/admin/verifications?status=${encode(status)}&kind=${encode(kind)}`),
    verificationDetail: (id) => request(`/api/admin/verifications/${encode(id)}`),
    reviewVerification: (id, action, reason = "") => request(
      `/api/admin/verifications/${encode(id)}/${encode(action)}`,
      { method: "POST", body: { reason } },
    ),
    verificationSettings: () => request("/api/admin/verification-settings"),
    setDemoLicenseEnabled: (enabled) => request("/api/admin/verification-settings", {
      method: "PUT",
      body: { demoLicenseEnabled: enabled },
    }),
    setAutoReviewEnabled: (enabled) => request("/api/admin/verification-settings", {
      method: "PUT",
      body: { autoReviewEnabled: enabled },
    }),
    runAutoReview: () => request("/api/admin/verifications/auto-review", { method: "POST", body: {} }),
    reservationStatus: () => request("/api/admin/reservations/status"),
    setReservationsEnabled: (enabled) => request("/api/admin/reservations/status", { method: "PUT", body: { enabled } }),
    logout: async () => {
      try { await request("/api/auth/logout", { method: "POST" }); }
      finally {
        localStorage.removeItem(activeKeys().token);
        localStorage.removeItem(activeKeys().refresh);
        if (activeScope === "admin" && currentAccountId) {
          const saved = readSavedAccounts();
          delete saved[currentAccountId];
          writeSavedAccounts(saved);
          currentAccountId = "";
        }
      }
    },
    // Account switcher: only administrator and staff sessions are saved.
    savedAccounts: () => Object.values(readSavedAccounts()).map((entry) =>
      Object.fromEntries(SAVED_PROFILE_FIELDS.map((field) => [field, entry[field] ?? ""]))),
    get currentAccountId() { return currentAccountId; },
    rememberAccount: (profile) => {
      const token = localStorage.getItem(SESSION_KEYS.admin.token);
      if (activeScope !== "admin" || !profile?.id || !token || profile.role === "User") return;
      const saved = readSavedAccounts();
      saved[profile.id] = {
        ...saved[profile.id],
        ...Object.fromEntries(SAVED_PROFILE_FIELDS.map((field) => [field, profile[field] ?? saved[profile.id]?.[field] ?? ""])),
        token,
        refresh: localStorage.getItem(SESSION_KEYS.admin.refresh) || "",
        savedAt: new Date().toISOString(),
      };
      writeSavedAccounts(saved);
      currentAccountId = profile.id;
    },
    // Puts a saved account's session in use and confirms it with the server. Returns the page to open.
    switchAccount: async (userId) => {
      const saved = stashCurrentAccount();
      const target = saved[userId];
      if (!target?.token) throw new Error("That account is not saved on this device. Add it first.");
      if (userId === currentAccountId) return panelUrl(target);
      const previousId = currentAccountId;
      const previous = previousId ? saved[previousId] : null;
      activeScope = "admin";
      switchingAccounts = true;
      useSession(target);
      try {
        const user = (await request("/api/auth/me", {}, { preserveSessionOnUnauthorized: true })).user;
        if (!user || user.role === "User" || user.id !== userId) throw new Error("That session belongs to a different account.");
        currentAccountId = userId;
        return panelUrl(user);
      } catch (error) {
        // An ended or disabled session is forgotten, and the account in use stays signed in.
        const ended = [401, 403].includes(error.status);
        const remaining = readSavedAccounts();
        if (ended) delete remaining[userId];
        writeSavedAccounts(remaining);
        if (previous?.token) useSession(previous);
        switchingAccounts = false;
        throw new Error(ended
          ? `${target.displayName || "That account"} is no longer signed in on this device. Add it again with its password.`
          : error.message);
      }
    },
    // Keeps the current session saved and clears it from use, so the sign-in page can add another account.
    prepareAddAccount: () => {
      stashCurrentAccount();
      localStorage.removeItem(SESSION_KEYS.admin.token);
      localStorage.removeItem(SESSION_KEYS.admin.refresh);
      currentAccountId = "";
    },
    // With no session in use (for example after leaving "Add account" unfinished), returns to
    // the most recently used saved account. The server still decides whether it is valid.
    resumeSavedAccount: () => {
      if (localStorage.getItem(SESSION_KEYS.admin.token)) return true;
      const latest = Object.values(readSavedAccounts()).filter((entry) => entry.token)
        .sort((a, b) => String(b.savedAt).localeCompare(String(a.savedAt)))[0];
      if (!latest) return false;
      useSession(latest);
      return true;
    },
    forgetAccount: (userId) => {
      const saved = readSavedAccounts();
      delete saved[userId];
      writeSavedAccounts(saved);
    },
    bookings: () => request("/api/bookings"),
    hotelBookings: () => request("/api/hotel/bookings"),
    parkingBookings: () => request("/api/parking/bookings"),
    // An idempotency key makes a resubmitted checkout return the first booking instead of a second one.
    createBooking: (type, details, { idempotencyKey } = {}) => request(`/api/${type.toLowerCase()}/bookings`, {
      method: "POST", body: details, headers: idempotencyKey ? { "Idempotency-Key": idempotencyKey } : {},
    }),
    createCombinedBooking: (details, { idempotencyKey } = {}) => request("/api/combined/bookings", {
      method: "POST", body: details, headers: idempotencyKey ? { "Idempotency-Key": idempotencyKey } : {},
    }),
    newIdempotencyKey,
    updateBooking: (id, details) => request(`/api/bookings/${encode(id)}`, { method: "PATCH", body: details }),
    action: (id, action, details = {}) => request(`/api/bookings/${encode(id)}/${encode(action)}`, { method: "PUT", body: details }),
    rooms: (checkIn, checkOut, bookingId = "") => request(`/api/rooms?checkIn=${encode(checkIn)}&checkOut=${encode(checkOut)}&bookingId=${encode(bookingId)}`),
    parkingSlots: (startAt, endAt, bookingId = "") => request(`/api/parking/slots?startAt=${encode(startAt)}&endAt=${encode(endAt)}&bookingId=${encode(bookingId)}`),
    demoInventory: () => Promise.all([
      request("/api/rooms"),
      request("/api/parking/slots"),
    ]).then(([rooms, parkingSlots]) => ({ rooms, parkingSlots })),
    notifications: () => request("/api/notifications"),
    markNotificationRead: (id) => request(`/api/notifications/${encode(id)}/read`, { method: "PUT", body: {} }),
    history: (id, type) => request(`/api/history?bookingId=${encode(id)}&type=${encode(type)}`),
    personnel: () => request("/api/personnel"),
    users: () => request("/api/users"),
    qrPasses: () => request("/api/qr/passes"),
    verifyQrPass: (receiptCode) => request(`/api/qr/verify/${encode(receiptCode)}`),
    // A mistyped confirmation password must not sign the administrator out.
    createAdmin: (details) => request("/api/admin/users", { method: "POST", body: details },
      { canRefresh: false, preserveSessionOnUnauthorized: true }),
    addPersonnel: (userId, department) => request("/api/personnel", { method: "POST", body: { userId, department } }),
    // Staff record what was paid at the desk or bank; NEXORA itself collects nothing.
    setPaymentStatus: (id, status) => request(`/api/bookings/${encode(id)}/payment`, { method: "PUT", body: { status } }),
    allUsers: () => request("/api/admin/users"),
    setUserRole: (id, role) => request(`/api/admin/users/${encode(id)}/role`, { method: "PUT", body: { role } }),
    setUserActive: (id, active) => request(`/api/admin/users/${encode(id)}/status`, { method: "PUT", body: { active } }),
    createRoom: (details) => request("/api/admin/rooms", { method: "POST", body: details }),
    updateRoom: (id, details) => request(`/api/admin/rooms/${encode(id)}`, { method: "PUT", body: details }),
    createParkingSlot: (details) => request("/api/admin/parking-slots", { method: "POST", body: details }),
    updateParkingSlot: (id, details) => request(`/api/admin/parking-slots/${encode(id)}`, { method: "PUT", body: details }),
    account: () => request("/api/account"),
    updateAccount: (details) => request("/api/account", { method: "PUT", body: details }),
    changePassword: (currentPassword, newPassword) => request("/api/account/password", {
      method: "POST",
      body: { currentPassword, newPassword },
    }, { canRefresh: false, preserveSessionOnUnauthorized: true }),
    exportAccount: () => request("/api/account/export"),
    deleteAccount: async (password) => {
      const result = await request("/api/account/delete", {
        method: "POST",
        body: { password, confirm: "DELETE" },
      }, { canRefresh: false, preserveSessionOnUnauthorized: true });
      localStorage.removeItem(activeKeys().token);
      localStorage.removeItem(activeKeys().refresh);
      return result;
    },
    serviceStatus: () => request("/api/health/ready"),
    reportProblem: async (details) => {
      const result = await request("/api/support/reports", {
        method: "POST",
        body: { ...details, requestId: lastFailedRequestId },
      });
      lastFailedRequestId = "";
      return result;
    },
    supportReports: () => request("/api/admin/support/reports"),
    replyToSupportReport: (reportId, message) => request(
      `/api/admin/support/reports/${encode(reportId)}/replies`,
      { method: "POST", body: { message } },
    ),
    auditLog: () => request("/api/admin/audit-log"),
    errorIncidents: (status = "open", severity = "", module = "") =>
      request(`/api/admin/errors?status=${encode(status)}&severity=${encode(severity)}&module=${encode(module)}`),
    updateErrorIncident: (id, status, note = "") => request(`/api/admin/errors/${encode(id)}`, {
      method: "PUT",
      body: { status, note },
    }),
    resolveAllErrorIncidents: (severity = "", module = "", note = "") => request("/api/admin/errors/resolve-all", {
      method: "POST",
      body: { severity, module, note },
    }),
    activityLog: () => request("/api/admin/activity-log"),
    // Department dashboards. The server decides the department and every permission.
    personnelMe: () => request("/api/personnel/me"),
    myActivity: () => request("/api/personnel/me/activity"),
    myPayments: () => request("/api/my/payments"),
    deskPaymentStatus: (type) => request(`/api/desk/payment-status${queryString({ type })}`),
    recordPayment: (bookingId, reference, note = "") => request(`/api/bookings/${encode(bookingId)}/payments`, {
      method: "POST", body: { reference, note },
    }),
    requestRefund: (bookingId, reason) => request(`/api/bookings/${encode(bookingId)}/refund-requests`, {
      method: "POST", body: { reason },
    }),
    setRoomStatus: (id, details) => request(`/api/hotel/rooms/${encode(id)}/status`, { method: "PUT", body: details }),
    setSlotStatus: (id, details) => request(`/api/parking/slots/${encode(id)}/status`, { method: "PUT", body: details }),
    finance: {
      summary: () => request("/api/finance/summary"),
      payments: (filters) => request(`/api/finance/payments${queryString(filters)}`),
      transactions: (filters) => request(`/api/finance/transactions${queryString(filters)}`),
      refunds: (filters) => request(`/api/finance/refunds${queryString(filters)}`),
      report: (params) => request(`/api/finance/reports${queryString(params)}`),
      auditLog: (q = "") => request(`/api/finance/audit-log${queryString({ q })}`),
      verifyPayment: (id, note = "") => request(`/api/finance/payments/${encode(id)}/verify`, { method: "POST", body: { note } }),
      rejectPayment: (id, note) => request(`/api/finance/payments/${encode(id)}/reject`, { method: "POST", body: { note } }),
      returnPayment: (id, note) => request(`/api/finance/payments/${encode(id)}/return`, { method: "POST", body: { note } }),
      settlePayment: (id, note = "") => request(`/api/finance/payments/${encode(id)}/settle`, { method: "POST", body: { note } }),
      approveRefund: (id, note = "") => request(`/api/finance/refunds/${encode(id)}/approve`, { method: "POST", body: { note } }),
      rejectRefund: (id, note) => request(`/api/finance/refunds/${encode(id)}/reject`, { method: "POST", body: { note } }),
      completeRefund: (id, payoutReference) => request(`/api/finance/refunds/${encode(id)}/complete`, {
        method: "POST", body: { payoutReference },
      }),
    },
    // Super Admin personnel management.
    staffList: () => request("/api/admin/personnel"),
    createStaff: (details) => request("/api/admin/personnel", { method: "POST", body: details }),
    setStaffStatus: (id, status, reason = "") => request(`/api/admin/personnel/${encode(id)}/status`, {
      method: "PUT", body: { status, reason },
    }),
    setStaffDepartment: (id, department) => request(`/api/admin/personnel/${encode(id)}/department`, {
      method: "PUT", body: { department },
    }),
    resetStaffCredentials: (id) => request(`/api/admin/personnel/${encode(id)}/reset-credentials`, { method: "POST", body: {} }),
    staffActivity: (id) => request(`/api/admin/personnel/${encode(id)}/activity`),
    accountDirectory: () => request("/api/admin/accounts"),
    setAccountPurpose: (id, purpose, importance) => request(`/api/admin/accounts/${encode(id)}/purpose`, {
      method: "PUT", body: { purpose, importance },
    }),
  };
})();