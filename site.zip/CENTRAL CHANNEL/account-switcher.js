/* The account switcher menu shared by the Central Channel (admin.html) and the department
   dashboards (personnel.html). It lists the administrator and staff accounts saved on this
   device (see savedAccounts in api-client.js), each with its purpose and importance, and
   switches between them without signing out. Styling uses the pages' shared colour tokens. */
(() => {
  const LOGIN = "../LOGO/LOGIN PANEL/index.html";
  const IMPORTANCE_TONE = { Critical: "err", High: "warn", Standard: "info", Limited: "mut" };
  const esc = (value = "") => String(value ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[c]);
  const initials = (name) => String(name || "?").split(/\s+/).map((part) => part[0]).slice(0, 2).join("").toUpperCase();
  const roleLabel = (account) => account.role === "Admin" ? "Administrator" : account.role || "Staff";

  const style = document.createElement("style");
  style.textContent = `
    .acct-wrap { position: relative; }
    .acct-menu { position: absolute; right: 0; top: calc(100% + 8px); z-index: 60; width: min(360px, calc(100vw - 32px));
      max-height: min(70vh, 560px); overflow: auto; padding: 8px; border: 1px solid var(--ln); border-radius: 12px;
      background: var(--sf); color: var(--ink); box-shadow: var(--sh); font: 400 14px/1.45 var(--fb); }
    .acct-menu h3 { margin: 4px 8px 8px; font: 600 12px/1.3 var(--fb); letter-spacing: .04em; text-transform: uppercase; color: var(--mut); }
    .acct-item { display: grid; grid-template-columns: 34px 1fr; gap: 10px; width: 100%; padding: 8px; border: 0; border-radius: 8px;
      background: transparent; color: inherit; font: inherit; text-align: left; cursor: pointer; }
    .acct-item:hover:not([aria-current]), .acct-item:focus-visible { background: var(--sf2); }
    .acct-item[aria-current] { cursor: default; background: var(--okbg); }
    .acct-avatar { display: grid; place-items: center; width: 34px; height: 34px; border-radius: 50%; background: var(--pri); color: #fff; font-weight: 600; font-size: 12px; }
    .acct-name { display: flex; flex-wrap: wrap; align-items: center; gap: 6px; font-weight: 600; }
    .acct-sub { color: var(--mut); font-size: 12.5px; }
    .acct-purpose { margin-top: 2px; font-size: 12.5px; }
    .acct-tag { padding: 1px 7px; border-radius: 999px; font-size: 11px; font-weight: 600; }
    .acct-tag.err { background: var(--errbg); color: var(--err); } .acct-tag.warn { background: var(--warnbg); color: var(--warn); }
    .acct-tag.info { background: var(--infobg); color: var(--info); } .acct-tag.mut { background: var(--sf2); color: var(--mut); }
    .acct-tag.ok { background: var(--okbg); color: var(--ok); }
    .acct-actions { display: grid; gap: 4px; margin-top: 6px; padding-top: 6px; border-top: 1px solid var(--ln); }
    .acct-action { padding: 8px; border: 0; border-radius: 8px; background: transparent; color: inherit; font: inherit; text-align: left; cursor: pointer; }
    .acct-action:hover, .acct-action:focus-visible { background: var(--sf2); }
    .acct-note { margin: 6px 8px 2px; color: var(--mut); font-size: 12px; }
    .acct-error { margin: 6px 8px; color: var(--err); font-size: 12.5px; }
  `;
  document.head.append(style);

  /* button: the toolbar button that opens the menu.
     options.onSignOut: signs out of the account in use (the page's own sign-out flow). */
  function attach(button, { onSignOut } = {}) {
    const api = window.ReservationAPI;
    const wrap = document.createElement("div");
    wrap.className = "acct-wrap";
    button.replaceWith(wrap);
    wrap.append(button);
    const menu = document.createElement("div");
    menu.className = "acct-menu";
    menu.id = "accountSwitcherMenu";
    menu.setAttribute("role", "menu");
    menu.hidden = true;
    wrap.append(menu);
    button.setAttribute("aria-haspopup", "menu");
    button.setAttribute("aria-controls", menu.id);
    button.setAttribute("aria-expanded", "false");

    const close = () => { menu.hidden = true; button.setAttribute("aria-expanded", "false"); };
    function render(error = "") {
      const current = api.currentAccountId;
      const accounts = api.savedAccounts().sort((a, b) =>
        (b.id === current) - (a.id === current) || String(a.displayName).localeCompare(String(b.displayName)));
      menu.innerHTML = `<h3>Accounts on this device</h3>
        ${accounts.map((account) => {
          const inUse = account.id === current;
          return `<button class="acct-item" type="button" role="menuitem" data-account="${esc(account.id)}"${inUse ? ' aria-current="true"' : ""}>
            <span class="acct-avatar" aria-hidden="true">${esc(initials(account.displayName || account.username))}</span>
            <span><span class="acct-name">${esc(account.displayName || account.username)}
              ${account.importance ? `<span class="acct-tag ${IMPORTANCE_TONE[account.importance] || "mut"}">${esc(account.importance)}</span>` : ""}
              ${inUse ? '<span class="acct-tag ok">In use</span>' : ""}</span>
              <span class="acct-sub">${esc(roleLabel(account))}${account.department && account.role !== "Admin" ? ` · ${esc(account.department)} dashboard` : account.role === "Admin" ? " · Central Channel" : ""}</span>
              ${account.purpose ? `<span class="acct-purpose" style="display:block">${esc(account.purpose)}</span>` : ""}</span>
          </button>`;
        }).join("") || '<p class="acct-note">No accounts saved yet.</p>'}
        ${error ? `<p class="acct-error" role="alert">${esc(error)}</p>` : ""}
        <div class="acct-actions">
          <button class="acct-action" type="button" role="menuitem" data-acct-add>+ Add another account</button>
          ${onSignOut ? '<button class="acct-action" type="button" role="menuitem" data-acct-signout>Sign out of this account</button>' : ""}
        </div>
        <p class="acct-note">Each account signs in once with its own password. Anyone using this browser can switch to saved accounts, so add them only on your own device. Signing out of an account removes it from this list.</p>`;
    }

    button.addEventListener("click", (event) => {
      event.stopPropagation();
      if (!menu.hidden) { close(); return; }
      render();
      menu.hidden = false;
      button.setAttribute("aria-expanded", "true");
      menu.querySelector("[data-account]:not([aria-current]), [data-acct-add]")?.focus();
    });
    document.addEventListener("click", (event) => { if (!wrap.contains(event.target)) close(); });
    document.addEventListener("keydown", (event) => {
      if (event.key === "Escape" && !menu.hidden) { close(); button.focus(); }
    });
    menu.addEventListener("click", async (event) => {
      const item = event.target.closest("[data-account]");
      if (item && !item.hasAttribute("aria-current")) {
        item.disabled = true;
        try {
          location.href = await api.switchAccount(item.dataset.account);
        } catch (error) {
          render(error.message);
        }
        return;
      }
      if (event.target.closest("[data-acct-add]")) {
        api.prepareAddAccount();
        const url = new URL(LOGIN, location.href);
        url.searchParams.set("portal", "admin");
        url.searchParams.set("reason", "add-account");
        location.href = url.href;
        return;
      }
      if (event.target.closest("[data-acct-signout]")) {
        close();
        onSignOut();
      }
    });
    return { refresh: () => { if (!menu.hidden) render(); } };
  }

  // Opens a saved account directly, for the Super Admin's account list.
  async function switchTo(userId) {
    location.href = await window.ReservationAPI.switchAccount(userId);
  }

  window.NexoraAccountSwitcher = { attach, switchTo };
})();
