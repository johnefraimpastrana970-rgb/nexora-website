/* CHICHI AI: the floating NEXORA assistant.
   Loaded after api-client.js on the customer, admin and department pages. It talks only to
   the NEXORA API (never to Groq), shows nothing until someone is signed in, and renders every
   reply as plain text. Page links come from the server's allow-list and are followed with the
   page's own navigation, so the assistant never invents a route. */
(() => {
  if (window.ChichiAssistant || !window.ReservationAPI) return;
  // API key: set GROQ_API_KEY in the backend environment; never put the secret in this browser file.
  const api = window.ReservationAPI; 
  const file = decodeURIComponent(location.pathname).toLowerCase().split("/").pop();
  const PAGE = file === "admin.html" ? "admin" : file === "personnel.html" ? "personnel" : "customer";
  const PAGE_URLS = {
    customer: "../HOME%20PAGE/main.html",
    admin: "../CENTRAL%20CHANNEL/admin.html",
    personnel: "../CENTRAL%20CHANNEL/personnel.html",
  };
  const STORE_KEY = `nexora-chichi-${PAGE}`;
  const MAX_INPUT = 1000;
  const GREETING = PAGE === "customer"
    ? "Hi! I'm CHICHI, your NEXORA assistant. Ask me about hotel stays, parking, your bookings, verification or your account, and I'll point you to the right page."
    : "Hi! I'm CHICHI, your NEXORA assistant. Ask me about your department's work or where to find something in NEXORA.";

  const style = document.createElement("style");
  style.textContent = `
    .chichi { --c-sf: var(--sf, #faf6f3); --c-sf2: var(--sf2, #f1ebe0); --c-ink: var(--ink, #2b2e2a); --c-mut: var(--mut, #5f6159);
      --c-ln: var(--ln, #d3d3c6); --c-pri: var(--pri, #46564a); --c-cta: var(--cta, #ddbea8); --c-on-cta: var(--on-cta, #2f2a25);
      --c-lift: 0px; position: fixed; right: max(16px, env(safe-area-inset-right)); bottom: calc(16px + env(safe-area-inset-bottom) + var(--c-lift));
      z-index: 90; font: inherit; color: var(--c-ink); }
    /* 90 keeps the assistant under every page dialog (100 and up), so it never covers a modal's buttons. */
    @media (max-width: 760px) { .chichi { --c-lift: 72px; } }
    .chichi *, .chichi *::before, .chichi *::after { box-sizing: border-box; }
    .chichi-fab { width: 56px; height: 56px; border-radius: 50%; border: 0; cursor: pointer; display: grid; place-items: center;
      background: var(--c-pri); color: #fff; box-shadow: 0 8px 24px rgba(0,0,0,.22); transition: transform .2s ease, box-shadow .2s ease; }
    .chichi-fab:hover { transform: translateY(-2px); box-shadow: 0 12px 28px rgba(0,0,0,.26); }
    .chichi-fab:focus-visible, .chichi button:focus-visible, .chichi textarea:focus-visible { outline: 3px solid var(--c-cta); outline-offset: 2px; }
    .chichi-fab svg { width: 26px; height: 26px; }
    .chichi[data-open="true"] .chichi-fab { transform: scale(.9); }
    .chichi-panel { position: absolute; right: 0; bottom: 68px; width: min(380px, calc(100vw - 32px)); height: min(560px, calc(100vh - 120px));
      display: flex; flex-direction: column; background: var(--c-sf); border: 1px solid var(--c-ln); border-radius: 16px; overflow: hidden;
      box-shadow: 0 18px 48px rgba(0,0,0,.24); transform-origin: bottom right; transition: opacity .18s ease, transform .18s ease; }
    .chichi-panel[hidden] { display: flex; opacity: 0; transform: translateY(8px) scale(.97); pointer-events: none; visibility: hidden; }
    .chichi-head { display: flex; align-items: center; gap: 10px; padding: 12px 12px 12px 16px; background: var(--c-pri); color: #fff; }
    .chichi-head b { display: block; font-size: 1rem; letter-spacing: .02em; }
    .chichi-head small { display: block; opacity: .82; font-size: .75rem; }
    .chichi-head > div { flex: 1; min-width: 0; }
    .chichi-icon { width: 34px; height: 34px; border: 0; border-radius: 8px; background: transparent; color: inherit; cursor: pointer; display: grid; place-items: center; }
    .chichi-icon:hover { background: rgba(255,255,255,.14); }
    .chichi-icon svg { width: 18px; height: 18px; }
    .chichi-log { flex: 1; overflow-y: auto; padding: 14px; display: flex; flex-direction: column; gap: 10px; overscroll-behavior: contain; }
    .chichi-msg { max-width: 86%; display: flex; flex-direction: column; gap: 4px; animation: chichi-in .2s ease; }
    .chichi-msg p { margin: 0; padding: 9px 12px; border-radius: 14px; white-space: pre-wrap; overflow-wrap: anywhere; line-height: 1.45; font-size: .92rem; }
    .chichi-msg time { font-size: .7rem; color: var(--c-mut); }
    .chichi-msg.bot { align-self: flex-start; }
    .chichi-msg.bot p { background: var(--c-sf2); border-bottom-left-radius: 4px; }
    .chichi-msg.me { align-self: flex-end; align-items: flex-end; }
    .chichi-msg.me p { background: var(--c-pri); color: #fff; border-bottom-right-radius: 4px; }
    .chichi-msg.err p { background: transparent; border: 1px solid #c0533f; color: var(--c-ink); }
    .chichi-links { display: flex; flex-wrap: wrap; gap: 6px; }
    .chichi-links button, .chichi-retry { border: 1px solid var(--c-ln); background: var(--c-sf); color: var(--c-ink); border-radius: 999px;
      padding: 6px 12px; font: inherit; font-size: .82rem; cursor: pointer; transition: background .15s ease, border-color .15s ease; }
    .chichi-links button:hover, .chichi-retry:hover { background: var(--c-cta); border-color: var(--c-cta); color: var(--c-on-cta); }
    .chichi-links button::after { content: " \\2192"; }
    .chichi-typing { align-self: flex-start; display: flex; gap: 4px; padding: 12px 14px; background: var(--c-sf2); border-radius: 14px; }
    .chichi-typing span { width: 7px; height: 7px; border-radius: 50%; background: var(--c-mut); animation: chichi-dot 1s infinite ease-in-out; }
    .chichi-typing span:nth-child(2) { animation-delay: .15s; } .chichi-typing span:nth-child(3) { animation-delay: .3s; }
    .chichi-form { border-top: 1px solid var(--c-ln); padding: 10px; display: flex; gap: 8px; align-items: flex-end; background: var(--c-sf); }
    .chichi-form textarea { flex: 1; resize: none; min-height: 40px; max-height: 120px; padding: 9px 11px; border: 1px solid var(--c-ln); border-radius: 12px;
      background: var(--c-sf); color: var(--c-ink); font: inherit; font-size: .92rem; line-height: 1.35; }
    .chichi-send { width: 40px; height: 40px; flex: none; border: 0; border-radius: 12px; background: var(--c-pri); color: #fff; cursor: pointer; display: grid; place-items: center; }
    .chichi-send:disabled { opacity: .5; cursor: default; }
    .chichi-send svg { width: 18px; height: 18px; }
    .chichi-foot { padding: 0 12px 8px; font-size: .7rem; color: var(--c-mut); display: flex; justify-content: space-between; gap: 8px; }
    @keyframes chichi-in { from { opacity: 0; transform: translateY(4px); } to { opacity: 1; transform: none; } }
    @keyframes chichi-dot { 0%, 80%, 100% { opacity: .3; transform: translateY(0); } 40% { opacity: 1; transform: translateY(-3px); } }
    @media (max-width: 480px) {
      .chichi-panel { position: fixed; inset: auto 8px calc(8px + env(safe-area-inset-bottom)) 8px; width: auto; height: min(78vh, 600px); bottom: calc(8px + env(safe-area-inset-bottom)); }
      .chichi[data-open="true"] .chichi-fab { opacity: 0; pointer-events: none; }
    }
    @media (prefers-reduced-motion: reduce) { .chichi *, .chichi *::before { animation: none !important; transition: none !important; } }
  `;
  document.head.appendChild(style);

  const icon = (path) => `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${path}</svg>`;
  const root = document.createElement("div");
  root.className = "chichi";
  root.dataset.open = "false";
  root.hidden = true;
  root.innerHTML = `
    <section class="chichi-panel" id="chichiPanel" role="dialog" aria-label="CHICHI AI assistant" hidden>
      <header class="chichi-head">
        <div><b>CHICHI AI</b><small>NEXORA hotel and parking assistant</small></div>
        <button class="chichi-icon" type="button" data-chichi="clear" aria-label="Clear conversation" title="Clear conversation">${icon('<path d="M3 6h18M8 6V4h8v2M6 6l1 14h10l1-14"/>')}</button>
        <button class="chichi-icon" type="button" data-chichi="close" aria-label="Close assistant" title="Close">${icon('<path d="m18 6-12 12M6 6l12 12"/>')}</button>
      </header>
      <div class="chichi-log" role="log" aria-live="polite" aria-relevant="additions"></div>
      <form class="chichi-form">
        <label class="chichi-sr" for="chichiInput" style="position:absolute;left:-9999px">Message CHICHI</label>
        <textarea id="chichiInput" rows="1" maxlength="${MAX_INPUT}" placeholder="Ask about stays, parking or your account…" autocomplete="off"></textarea>
        <button class="chichi-send" type="submit" aria-label="Send message">${icon('<path d="M22 2 11 13M22 2l-7 20-4-9-9-4 20-7z"/>')}</button>
      </form>
      <div class="chichi-foot"><span>CHICHI can make mistakes. Check details on the page.</span><span class="chichi-count"></span></div>
    </section>
    <button class="chichi-fab" type="button" aria-label="Open CHICHI AI assistant" aria-expanded="false" aria-controls="chichiPanel" title="CHICHI AI">
      ${icon('<path d="M21 12a8 8 0 0 1-11.8 7L4 20l1.1-4.6A8 8 0 1 1 21 12z"/><path d="M8.5 11h.01M12 11h.01M15.5 11h.01"/>')}
    </button>`;
  document.body.appendChild(root);

  const $ = (selector) => root.querySelector(selector);
  const panel = $(".chichi-panel"), log = $(".chichi-log"), form = $(".chichi-form"), input = $("#chichiInput");
  const fab = $(".chichi-fab"), send = $(".chichi-send"), count = $(".chichi-count");
  let history = load();
  let busy = false;

  function load() {
    try {
      const saved = JSON.parse(sessionStorage.getItem(STORE_KEY));
      return Array.isArray(saved) ? saved.filter((m) => m && (m.role === "user" || m.role === "assistant")).slice(-40) : [];
    } catch { return []; }
  }
  function save() {
    try { sessionStorage.setItem(STORE_KEY, JSON.stringify(history.slice(-40))); } catch { /* private mode: history lasts until reload */ }
  }
  const clock = (iso) => {
    const date = iso ? new Date(iso) : new Date();
    return Number.isNaN(date.getTime()) ? "" : date.toLocaleTimeString([], { hour: "numeric", minute: "2-digit" });
  };

  function bubble(kind, text, time) {
    const item = document.createElement("div");
    item.className = `chichi-msg ${kind}`;
    const body = document.createElement("p");
    body.textContent = text;
    item.appendChild(body);
    if (time !== null) {
      const stamp = document.createElement("time");
      stamp.textContent = clock(time);
      if (time) stamp.dateTime = time;
      item.appendChild(stamp);
    }
    log.appendChild(item);
    return item;
  }
  function addLinks(item, links) {
    if (!Array.isArray(links) || !links.length) return;
    const row = document.createElement("div");
    row.className = "chichi-links";
    links.forEach((link) => {
      if (!link || !PAGE_URLS[link.page] || typeof link.view !== "string") return;
      const button = document.createElement("button");
      button.type = "button";
      button.textContent = `Open ${link.label}`;
      button.addEventListener("click", () => navigate(link));
      row.appendChild(button);
    });
    item.insertBefore(row, item.querySelector("time"));
  }
  function render() {
    log.textContent = "";
    bubble("bot", GREETING, null);
    history.forEach((message) => {
      const item = bubble(message.role === "user" ? "me" : "bot", message.content, message.time || "");
      if (message.role === "assistant") addLinks(item, message.links);
    });
    scrollDown();
  }
  const scrollDown = () => requestAnimationFrame(() => { log.scrollTop = log.scrollHeight; });

  // Follows a link with the page's own navigation: the same menus a person would click.
  function navigate(link) {
    const view = String(link.view).replace(/[^\w-]/g, "");
    if (link.page !== PAGE) {
      location.href = `${PAGE_URLS[link.page]}#${view}`;
      return;
    }
    if (PAGE === "customer") {
      window.dispatchEvent(new CustomEvent("nexora:navigate", { detail: { service: link.service || "", view } }));
    } else {
      const selector = PAGE === "admin"
        ? `.nav-link[href="#${view}"]${link.queue ? `[data-view="${String(link.queue).replace(/\W/g, "")}"]` : ""}`
        : `#nav .nav-link[data-view="${view}"]`;
      const target = document.querySelector(selector);
      if (target) target.click();
      else location.hash = view;
    }
    if (matchMedia("(max-width: 480px)").matches) setOpen(false);
  }

  function friendlyError(error) {
    if (error?.status === 401) return "Your session has expired. Sign in again to keep chatting.";
    if (error?.code === "assistant_not_configured") return "CHICHI isn't set up on this server yet. Please ask a NEXORA administrator.";
    if (error?.code === "consent_required") return "Please review and accept the updated NEXORA policies first, then try again.";
    if (error?.status === 429) return "You're sending messages quickly. Please wait a moment and try again.";
    if (!error?.status) return "CHICHI can't reach NEXORA right now. Check your connection and try again.";
    return error.message || "Something went wrong. Please try again.";
  }

  async function ask() {
    if (busy) return;
    busy = true;
    send.disabled = true;
    const typing = document.createElement("div");
    typing.className = "chichi-typing";
    typing.setAttribute("aria-label", "CHICHI is typing");
    typing.innerHTML = "<span></span><span></span><span></span>";
    log.appendChild(typing);
    scrollDown();
    try {
      const outgoing = history.slice(-12).map(({ role, content }) => ({ role, content }));
      const result = await api.assistantChat(outgoing);
      const message = { role: "assistant", content: String(result?.reply || ""), links: result?.links || [], time: result?.answeredAt || new Date().toISOString() };
      if (!message.content) throw new Error("CHICHI could not form an answer. Try asking in a different way.");
      history.push(message);
      save();
      typing.remove();
      addLinks(bubble("bot", message.content, message.time), message.links);
    } catch (error) {
      typing.remove();
      const item = bubble("bot err", friendlyError(error), new Date().toISOString());
      if (error?.status !== 401 && error?.code !== "assistant_not_configured") {
        const retry = document.createElement("button");
        retry.type = "button";
        retry.className = "chichi-retry";
        retry.textContent = "Try again";
        retry.addEventListener("click", () => { item.remove(); ask(); });
        item.insertBefore(retry, item.querySelector("time"));
      }
    } finally {
      busy = false;
      send.disabled = false;
      scrollDown();
    }
  }

  function submit() {
    const text = input.value.trim();
    if (!text || busy) return;
    const message = { role: "user", content: text.slice(0, MAX_INPUT), time: new Date().toISOString() };
    history.push(message);
    save();
    bubble("me", message.content, message.time);
    input.value = "";
    resize();
    ask();
  }
  function resize() {
    input.style.height = "auto";
    input.style.height = `${Math.min(input.scrollHeight, 120)}px`;
    count.textContent = input.value.length > MAX_INPUT * 0.8 ? `${input.value.length}/${MAX_INPUT}` : "";
  }
  function setOpen(open) {
    root.dataset.open = String(open);
    panel.hidden = !open;
    fab.setAttribute("aria-expanded", String(open));
    fab.setAttribute("aria-label", open ? "Close CHICHI AI assistant" : "Open CHICHI AI assistant");
    if (open) { scrollDown(); setTimeout(() => input.focus(), 60); }
  }

  fab.addEventListener("click", () => setOpen(panel.hidden));
  $('[data-chichi="close"]').addEventListener("click", () => { setOpen(false); fab.focus(); });
  $('[data-chichi="clear"]').addEventListener("click", () => {
    if (busy) return;
    history = [];
    save();
    render();
    input.focus();
  });
  form.addEventListener("submit", (event) => { event.preventDefault(); submit(); });
  input.addEventListener("input", resize);
  input.addEventListener("keydown", (event) => {
    if (event.key === "Enter" && !event.shiftKey && !event.isComposing) { event.preventDefault(); submit(); }
  });
  root.addEventListener("keydown", (event) => {
    if (event.key === "Escape" && !panel.hidden) { setOpen(false); fab.focus(); }
  });

  // Shown only while someone is signed in; the server checks the session on every message anyway.
  function syncVisibility() {
    const signedIn = api.signedIn;
    root.hidden = !signedIn;
    if (!signedIn && !panel.hidden) setOpen(false);
  }
  render();
  syncVisibility();
  setInterval(syncVisibility, 4000);
  window.addEventListener("storage", syncVisibility);
  document.addEventListener("visibilitychange", syncVisibility);

  window.ChichiAssistant = { open: () => setOpen(true), close: () => setOpen(false) };
})();
